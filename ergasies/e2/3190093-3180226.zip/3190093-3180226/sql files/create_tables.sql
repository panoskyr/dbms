BEGIN;
\i 'C:/Users/pchrk/OneDrive/Desktop/cs/2nd year/d examino/vaseis/vaseis 2021/airbnb dataset/sql files/create_calendar.sql'
\i 'C:/Users/pchrk/OneDrive/Desktop/cs/2nd year/d examino/vaseis/vaseis 2021/airbnb dataset/sql files/create_neighbourhoods.sql'
\i 'C:/Users/pchrk/OneDrive/Desktop/cs/2nd year/d examino/vaseis/vaseis 2021/airbnb dataset/sql files/create_geolocation.sql'
\i 'C:/Users/pchrk/OneDrive/Desktop/cs/2nd year/d examino/vaseis/vaseis 2021/airbnb dataset/sql files/create_listings.sql'
\i 'C:/Users/pchrk/OneDrive/Desktop/cs/2nd year/d examino/vaseis/vaseis 2021/airbnb dataset/sql files/create_listings_summary.sql'
\i 'C:/Users/pchrk/OneDrive/Desktop/cs/2nd year/d examino/vaseis/vaseis 2021/airbnb dataset/sql files/create_reviews.sql'
\i 'C:/Users/pchrk/OneDrive/Desktop/cs/2nd year/d examino/vaseis/vaseis 2021/airbnb dataset/sql files/create_reviews_summary.sql'
COMMIT;