create table Reviews_Summary(
   listing_id int,
   date date
   --PRIMARY KEY(listing_id,date)
);
