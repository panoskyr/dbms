create table Neighbourhoods(
   neighbourhood_group varchar(100),
   neighbourhood varchar(400),
   PRIMARY KEY(neighbourhood)
);